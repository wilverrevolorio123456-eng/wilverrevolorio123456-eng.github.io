// Crea la primera cuenta administrativa. Ejecute: npm run create-admin
const fs = require('fs');
const path = require('path');
const readline = require('readline');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');

const dataDir = path.join(__dirname, '..', 'data');
const usersFile = path.join(dataDir, 'users.json');
fs.mkdirSync(dataDir, { recursive: true });
const users = (() => { try { return JSON.parse(fs.readFileSync(usersFile, 'utf8')); } catch { return []; } })();
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const ask = (q) => new Promise(resolve => rl.question(q, resolve));
(async () => {
  try {
    const username = (await ask('Usuario administrador (sin espacios): ')).trim().toLowerCase();
    if (!/^[a-z0-9._-]{3,40}$/.test(username)) throw new Error('Use 3-40 caracteres: letras, números, punto, guion o guion bajo.');
    if (users.some(u => u.username.toLowerCase() === username)) throw new Error('Ese usuario ya existe.');
    const password = await ask('Contraseña (mínimo 14 caracteres): ');
    if (password.length < 14) throw new Error('La contraseña debe tener al menos 14 caracteres.');
    const confirm = await ask('Repita la contraseña: ');
    if (password !== confirm) throw new Error('Las contraseñas no coinciden.');
    const passwordHash = await bcrypt.hash(password, 12);
    users.push({ id: crypto.randomUUID(), username, passwordHash, active: true, createdAt: new Date().toISOString() });
    const tmp = usersFile + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(users, null, 2), { mode: 0o600 });
    fs.renameSync(tmp, usersFile);
    console.log(`Cuenta administrativa "${username}" creada.`);
    console.log('Guarde la contraseña en un gestor seguro. No se puede recuperar desde esta aplicación.');
  } catch (e) {
    console.error('No se creó la cuenta:', e.message);
    process.exitCode = 1;
  } finally { rl.close(); }
})();
