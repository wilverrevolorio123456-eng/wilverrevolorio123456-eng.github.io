const $ = (id) => document.getElementById(id);
const systemLink = $('systemLink');
const publicUrl = $('publicUrl');
const linkStatus = $('linkStatus');
const dialog = $('adminDialog');
let csrfToken = '';

async function request(url, options = {}) {
  const response = await fetch(url, {
    credentials: 'same-origin',
    ...options,
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || 'No fue posible completar la solicitud.');
  return data;
}
function showMessage(message, success = false) {
  const el = $('adminMessage');
  el.textContent = message;
  el.classList.toggle('success', success);
}
function renderPublicConfig(cfg) {
  const configured = Boolean(cfg.systemUrl);
  systemLink.href = configured ? cfg.systemUrl : '#';
  systemLink.setAttribute('aria-disabled', configured ? 'false' : 'true');
  if (configured) {
    systemLink.target = '_blank';
    systemLink.rel = 'noopener noreferrer';
    linkStatus.textContent = 'El enlace oficial está disponible. Se abrirá en una nueva pestaña.';
    publicUrl.classList.add('is-configured');
    publicUrl.replaceChildren();
    const dot = document.createElement('span'); dot.className = 'status-dot';
    const label = document.createElement('span'); label.textContent = cfg.systemUrl;
    publicUrl.append(dot, label);
  } else {
    systemLink.removeAttribute('target');
    systemLink.removeAttribute('rel');
    linkStatus.textContent = 'El enlace oficial está pendiente de configuración.';
    publicUrl.classList.remove('is-configured');
    publicUrl.replaceChildren();
    const dot = document.createElement('span'); dot.className = 'status-dot';
    const label = document.createElement('span'); label.textContent = 'Pendiente de configurar';
    publicUrl.append(dot, label);
  }
}
async function loadPublicConfig() {
  try { renderPublicConfig(await request('/api/public-config')); }
  catch { linkStatus.textContent = 'No se pudo consultar el estado del enlace. Intente recargar la página.'; }
}
systemLink.addEventListener('click', (event) => {
  if (systemLink.getAttribute('aria-disabled') === 'true') {
    event.preventDefault();
    linkStatus.textContent = 'El administrador todavía debe configurar el enlace oficial.';
  }
});
async function checkSession() {
  const state = await request('/api/admin/session');
  if (state.authenticated) {
    csrfToken = state.csrfToken;
    $('loginPanel').hidden = true;
    $('configPanel').hidden = false;
    $('loggedInAs').textContent = `Sesión iniciada como ${state.username}`;
    const cfg = await request('/api/admin/config');
    $('systemUrlInput').value = cfg.systemUrl || '';
  } else {
    csrfToken = '';
    $('loginPanel').hidden = false;
    $('configPanel').hidden = true;
  }
}
$('openAdmin').addEventListener('click', async () => {
  showMessage('');
  dialog.showModal();
  try { await checkSession(); } catch { showMessage('No se pudo verificar la sesión. Recargue la página.'); }
});
$('closeAdmin').addEventListener('click', () => dialog.close());
dialog.addEventListener('click', (event) => {
  if (event.target === dialog) dialog.close();
});
$('loginForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  showMessage('');
  const username = $('username').value;
  const password = $('password').value;
  try {
    const result = await request('/api/admin/login', { method: 'POST', body: JSON.stringify({ username, password }) });
    csrfToken = result.csrfToken;
    $('loginForm').reset();
    await checkSession();
    showMessage('Sesión iniciada correctamente.', true);
  } catch (error) { showMessage(error.message); }
});
$('configForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  showMessage('');
  try {
    const result = await request('/api/admin/config', {
      method: 'PUT',
      headers: { 'X-CSRF-Token': csrfToken },
      body: JSON.stringify({ systemUrl: $('systemUrlInput').value.trim() })
    });
    renderPublicConfig(result);
    showMessage('Enlace actualizado correctamente.', true);
  } catch (error) { showMessage(error.message); }
});
$('logoutButton').addEventListener('click', async () => {
  try {
    await request('/api/admin/logout', { method: 'POST', headers: { 'X-CSRF-Token': csrfToken }, body: '{}' });
    csrfToken = '';
    await checkSession();
    showMessage('Sesión cerrada.', true);
  } catch (error) { showMessage(error.message); }
});
loadPublicConfig();
